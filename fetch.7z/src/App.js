import React from "react";
import CharacterScreen from "./components/CharacterScreen";

function App() {
  return <CharacterScreen />;
}

export default App;
